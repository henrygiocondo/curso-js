var elParagraph = document.getElementById('paragrafo');
var texto = 'Olá mundo!';

elParagraph.textContent = texto;